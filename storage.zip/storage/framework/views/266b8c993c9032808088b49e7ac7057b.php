

<?php $__env->startSection('title','bluggle-bussiness-plus'); ?>
<?php $__env->startSection('content'); ?>
<main class="page_content">

<!-- Page Banner Section - Start
================================================== -->
<section class="software_company_hero_section xb-hidden ">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-12 a ">
            <div class="content-wraps text-center mt-3">
              <div class="content_wrap  ">
                <h1 class="text-white  ">
                 <mark>Pricing</mark> 
                   
                </h1>
                <h6 class="text-white " >Think Big! Do Big! Be Big! Together we are <mark class="ms-1">Bluggle</mark>
                </h6>
              </div>
            </div>
            <div class="shape_images_1">
              <img src="assets/images/hero/shape_image_1.webp" alt="Engine Image">
            </div>
            <div class="shape_images_2">
              <img src="assets/images/hero/shape_image_2.webp" alt="Engine Image">
            </div>
          </div>
          <!-- <div class="col-lg-4  ">
            <div class="content-wraps">
            <div class="img-work mt-5">
            <img src="assets/images/about/i-1.png" alt="Engine Image" width="210px" height="210px">
            </div>
            </div>
          </div> -->
        </div>
      </div>

</section>
<!-- Page Banner Section - End
================================================== -->

<!-- Policy Section - Start
================================================== -->

<!-- Policy Section - End
================================================== -->

<!-- Pricing Section - Start
================================================== -->
<section class="pricing_section section_space pb-5 bg-light">
  <div class="container">
    <div class="heading_block text-center">
      <div class="heading_focus_text mb-2">
        Our 
        <span class="badge bg-secondary text-white">Pricing 😍</span>
      </div>
      <h2 class="heading_text mb-0">
        Best Plane for Business
      </h2>
    </div>
    <div class="pricing_toggle_btn text-center">
      <button type="button">
        <span>Billed Monthly <small>-10%</small></span>
        <span>Billed Yearly <small>-30%</small></span>
      </button>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="pricing_block">
          <div class="table_head">
            <div class="pricing_price_value bg-primary-subtle text-primary">
              <span class="pricing_monthly">
                <del>$54</del> $48<small>.6</small> <sub>You'll Save <u>$5.4</u> Monthly</sub>
              </span>
              <span class="pricing_annually">
                <del>$648</del> $453<small>.6</small> <sub>You'll Save <u>$194.4</u> Annually</sub>
              </span>
            </div>
            <div class="pricing_block_title">
              <h3 class="pricing_package_title">Pro Package</h3>
              <p class="pricing_package_description mb-0">
                Make your work easier with an integrated properly together.
              </p>
            </div>
          </div>
          <ul class="icon_list unordered_list_block">
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Software Development.
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Digital Product Design
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                IT Consulting.
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Website Development.
              </span>
            </li>
            <li class="delete">
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Cybersecurity Services.
              </span>
            </li>
            <li class="delete">
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Cloud Services.
              </span>
            </li>
          </ul>
          <a class="btn btn-light" href="#!">
            <span class="btn_label" data-text="Purchase Now">Purchase Now</span>
            <span class="btn_icon">
              <i class="fa-solid fa-arrow-up-right"></i>
            </span>
          </a>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="pricing_block">
          <div class="best_plan">
            <img src="assets/images/icons/best_offer.svg.svg" alt="Best Offer">
          </div>
          <div class="table_head">
            <div class="pricing_price_value bg-primary-subtle text-primary">
              <span class="pricing_monthly">
                <del>$60</del> $54 <sub>You'll Save <u>$6</u> Monthly</sub>
              </span>
              <span class="pricing_annually">
                <del>$720</del> $504 <sub>You'll Save <u>$216</u> Annually</sub>
              </span>
            </div>
            <div class="pricing_block_title">
              <h3 class="pricing_package_title">Team Package</h3>
              <p class="pricing_package_description mb-0">
                Make your work easier with an integrated properly together.
              </p>
            </div>
          </div>
          <ul class="icon_list unordered_list_block">
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Software Development.
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Digital Product Design
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                IT Consulting.
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Website Development.
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Cybersecurity Services.
              </span>
            </li>
            <li>
              <span class="icon_list_icon">
                <i class="fa-regular fa-circle-check"></i>
              </span>
              <span class="icon_list_text">
                Cloud Services.
              </span>
            </li>
          </ul>
          <a class="btn btn-light" href="#!">
            <span class="btn_label" data-text="Purchase Now">Purchase Now</span>
            <span class="btn_icon">
              <i class="fa-solid fa-arrow-up-right"></i>
            </span>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Pricing Section - End
================================================== -->

<!-- Client Logo Section - Start
================================================== -->

<!-- Client Logo Section - End
================================================== -->

<!-- Call To Action Section - Start
================================================== -->
<section class="calltoaction_section parallaxie" style="background-image: url('assets/images/backgrounds/bg_image_1.webp');">
  <div class="container text-center">
    <div class="heading_block text-white">
      <h2 class="heading_text">
        Ready to Work, Let's Chat
      </h2>
      <p class="heading_description mb-0">
        Our team of experts is ready to collaborate with you every step of the way, from initial consultation to implementation.
      </p>
    </div>
    <a class="btn btn-primary" href="contact.html">
      <span class="btn_label" data-text="Contact Us Today!">Contact Us Today!</span>
      <span class="btn_icon">
        <i class="fa-solid fa-arrow-up-right"></i>
      </span>
    </a>
  </div>
</section>
<!-- Call To Action Section - End
================================================== -->

</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abish\Downloads\Bluggle_Groups_final\groups\resources\views\pricing.blade.php ENDPATH**/ ?>