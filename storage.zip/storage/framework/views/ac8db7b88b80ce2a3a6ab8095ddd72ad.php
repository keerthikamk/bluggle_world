

<?php $__env->startSection('title','about'); ?>
<?php $__env->startSection('content'); ?>
<main class="page_content">

<!-- Page Banner Section - Start
================================================== -->
    <section class="software_company_hero_section xb-hidden">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-12 a ">
            <div class="content-wraps text-center mt-3">
              <div class="content_wrap  ">
                <h1 class="text-white  ">
                    About <mark>US</mark>
                </h1>
                <h6 class="text-white " >Think Big! Do Big! Be Big! Together we are <mark class="ms-1">Bluggle</mark>
                </h6>
              </div>
            </div>
            <div class="shape_images_1">
              <img src="/assets/images/hero/shape_image_1.webp" alt="Engine Image">
            </div>
            <div class="shape_images_2">
              <img src="/assets/images/hero/shape_image_2.webp" alt="Engine Image">
            </div>
          </div>
          <!-- <div class="col-lg-4  ">
            <div class="content-wraps">
            <div class="img-work mt-5">
            <img src="/assets/images/about/i-1.png" alt="Engine Image" width="210px" height="210px">
            </div>
            </div>
          </div> -->
        </div>
      </div>

    </section>


        <!-- <section class="about_section section_space">
          <div class="container">
            <div class="row align-items-center justify-content-lg-between">
              <div class="col-lg-6">
                <div class="about_image_1">
                  <img src="/assets/images/about/about_image_9.webp" alt="Techco - About Image">
                  <img src="/assets/images/about/about_image_11.webp" data-parallax='{"y" : 80, "smoothness": 6}' alt="Techco - About Image">
                  <img src="/assets/images/about/about_image_10.webp" data-parallax='{"y" : -80, "smoothness": 6}' alt="Techco - About Image">
                </div>
            
              </div>
              <div class="col-lg-6">
                <div class="about_content">
                  <div class="heading_block">
                  
                    <h2 class="heading_text">
                    WHO WE ARE AND WHAT WE DO
                    </h2>
                    <p class="heading_description ">
                      <mark> Level up your game with Bluggle Groups</mark> <br>

                    We're all about unlocking your business potential with next-level solutions and expert advice by your side.</p>
                    <p class="heading_description ">
                    Think of us as your growth partner on steroids  -  we do killer digital marketing, strategy sessions for crushing your goals, property consulting to find your perfect space, and event management that'll have people raving.
                    </p>
                    <p class="heading_description ">
                    We're not stopping there - we've got fire webinars, education consulting to keep you ahead of the curve, and software solutions that'll streamline your hustle.
                    </p>
                    <p class="heading_description ">
                    Ready to take your success stratospheric? Join the Bluggle Groups fam and let's launch you to the moon together! 
                    </p>
                  </div>
              
                </div>
              </div>
                    
              <ul class="btns_group unordered_list p-0 justify-content-center">
                    <li>
                      <a class="btn" href="contact">
                        <span class="btn_label" data-text="Contact Us">Contact Us</span>
                        <span class="btn_icon">
                          <i class="fa-solid fa-arrow-up-right"></i>
                        </span>
                      </a>
                    </li>
                  
                  </ul>
            </div>
          </div>
        </section> -->



        <section class="about_section section_space bg-light">
          <div class="container">
            <div class="row align-items-center justify-content-lg-between">
              <div class="col-lg-6 order-lg-last">
                <div class="team_cartoon_image">
                  <img src="/assets/images/team/about1.webp" alt="Team Cartoon Image - Techco - About Image" class="radius">
                </div>
              </div>
              <div class="col-lg-5">
                <div class="about_content">
                  <div class="heading_block">
                    <!-- <div class="heading_focus_text">
                      Our Dedicated 
                      <span class="badge bg-secondary text-white">Team 🙂</span>
                    </div> -->
                    <h2 class="heading_text">
                    WHO WE ARE AND WHAT WE DO
                    </h2>
                    <p class="heading_description ">
                      <mark> Level up your game with Bluggle Groups</mark> <br>

                    We're all about unlocking your business potential with next-level solutions and expert advice by your side.</p>
                    <p class="heading_description ">
                    Think of us as your growth partner on steroids  -  we do killer digital marketing, strategy sessions for crushing your goals, property consulting to find your perfect space, and event management that'll have people raving.
                    </p>
                    <p class="heading_description ">
                    We're not stopping there - we've got fire webinars, education consulting to keep you ahead of the curve, and software solutions that'll streamline your hustle.
                    </p>
                    <p class="heading_description ">
                    Ready to take your success stratospheric? Join the Bluggle Groups fam and let's launch you to the moon together! 
                    </p>
                    <!-- <p class="heading_description mb-0">
                      Get acquainted with the powerhouse behind Techco – our expert team of professionals dedicated to revolutionizing the IT landscape. Comprising.
                    </p> -->
                  </div>
                  <a class="btn" href="contact.html">
                    <span class="btn_label" data-text="Contact Us">Contact Us</span>
                    <span class="btn_icon">
                      <i class="fa-solid fa-arrow-up-right"></i>
                    </span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Intro About Section - End
        ================================================== -->

        <!-- Policy Section - Start
        ================================================== -->
        <section class="policy_section bg-light pb-5 pt-5">
          <div class="container">
            <div class="row">
             
              <div class="col-lg-4">
                <div class="iconbox_block">
                  <div class="iconbox_icon bg-warning-subtle">
                    <img src="/assets/images/icons/icon_dart_board_2.svg" alt="Dart Board SVG Icon">
                  </div>
                  <div class="iconbox_content">
                    <h3 class="iconbox_title">Our Mission</h3>
                    <p class="mb-0">
                    "Empowering your business journey, BluggleGroups is your one-stop destination for comprehensive solutions, driving success through innovation and reliability."
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="iconbox_block">
                  <div class="iconbox_icon bg-secondary-subtle">
                    <img src="/assets/images/icons/icon_target.svg" alt="Target SVG Icon">
                  </div>
                  <div class="iconbox_content">
                    <h3 class="iconbox_title">Our Vision</h3>
                    <p class="mb-0">
                    At Bluggle, our customized customer service strengthens relationships, ensuring exceptional care for each client and setting us apart in the industry.
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="iconbox_block">
                  <div class="iconbox_icon">
                    <img src="/assets/images/icons/icon_clock.svg" alt="Clock SVG Icon">
                  </div>
                  <div class="iconbox_content">
                    <h3 class="iconbox_title">Our Objective</h3>
                    <p class="mb-0">
                    To uphold the highest moral and professional standards while building a better future, we remain steadfastly committed to ethical conduct and continuous improvement.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Policy Section - End
        ================================================== -->

        <!-- Client Logo Section - Start
        ================================================== -->
       
        <!-- Client Logo Section - End
        ================================================== -->

        <!-- Team Section - Start
        ================================================== -->
        <section class="team_section section_space xb-hidden">
        <div class="container">
            <div class="row align-items-center justify-content-lg-between">
              <div class="col-lg-6">
                <div class="image_wrap">
                  <img src="/assets/images/about/about_image_16.webp" alt="Techco - About Image" class="radius">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="ps-lg-5">
                  <div class="heading_block">
                   
                    <h2 class="heading_text mb-0">
                      Why Our Services are Better Than Others?
                    </h2>
                  </div>
                  <ul class="service_facilities_group unordered_list">
                    <li>
                      <a class="iconbox_block layout_icon_left" href="#">
                        <span class="iconbox_icon">
                          <img src="/assets/images/icons/icon_check_2.svg" alt="Check SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">Quality Comes First</strong>
                        </span>
                      </a>
                    </li>
                    <li>
                      <a class="iconbox_block layout_icon_left" href="#">
                        <span class="iconbox_icon">
                          <img src="/assets/images/icons/icon_leaf.svg" alt="Leaf SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">Flexible Cooperation</strong>
                        </span>
                      </a>
                    </li>
                    <li>
                      <a class="iconbox_block layout_icon_left" href="#">
                        <span class="iconbox_icon">
                          <img src="/assets/images/icons/icon_box.svg" alt="Box SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">On-time Delivery</strong>
                        </span>
                      </a>
                    </li>
                    <li>
                      <a class="iconbox_block layout_icon_left" href="#">
                        <span class="iconbox_icon">
                          <img src="/assets/images/icons/icon_receipt_add.svg" alt="Receipt Add SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">Transparent Costs</strong>
                        </span>
                      </a>
                    </li>
                    <li>
                      <a class="iconbox_block layout_icon_left" href="#">
                        <span class="iconbox_icon">
                          <img src="/assets/images/icons/icon_monitor.svg" alt="Monitor SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">Qualified Developers</strong>
                        </span>
                      </a>
                    </li>
                    <li>
                      <a class="iconbox_block layout_icon_left" href="#">
                        <span class="iconbox_icon">
                          <img src="/assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">Quick Scale-up</strong>
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Team Section - End
        ================================================== -->

        <!-- Service Section - Start
        ================================================== -->
        
        <!-- Service Section - End
        ================================================== -->

        <!-- Call To Action Section - Start
        ================================================== -->
        <section class="calltoaction_section parallaxie " style="background-image: url('/assets/images/backgrounds/bg_image_6.webp');">
          <div class="container text-center">
            <div class="heading_block text-white">
              <h2 class="heading_text">
                Ready to Work, Let's Chat
              </h2>
              <p class="heading_description mb-0">
                Our team of experts is ready to collaborate with you every step of the way, from initial consultation to implementation.
              </p>
            </div>
            <a class="btn btn-primary" href="contact">
              <span class="btn_label" data-text="Contact Us Today!">Contact Us Today!</span>
              <span class="btn_icon">
                <i class="fa-solid fa-arrow-up-right"></i>
              </span>
            </a>
          </div>
        </section>
        <!-- Call To Action Section - End
        ================================================== -->

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abish\Downloads\Bluggle_Groups_final\groups\resources\views/about.blade.php ENDPATH**/ ?>