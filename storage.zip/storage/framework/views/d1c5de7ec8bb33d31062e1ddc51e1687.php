

<?php $__env->startSection('title','Blogs'); ?>
<?php $__env->startSection('content'); ?>

<main class="page_content">

<!-- Page Banner Section - Start
================================================== -->
<section class="software_company_hero_section xb-hidden">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-12 a ">
            <div class="content-wraps text-center mt-3">
              <div class="content_wrap  ">
                <h1 class="text-white  ">
                Bluggle  <mark>Blogs</mark> 
                   
                </h1>
                <h6 class="text-white " >Think Big! Do Big! Be Big! Together we are <mark class="ms-1">Bluggle</mark>
                </h6>
              </div>
            </div>
            <div class="shape_images_1">
              <img src="assets/images/hero/shape_image_1.webp" alt="Engine Image">
            </div>
            <div class="shape_images_2">
              <img src="assets/images/hero/shape_image_2.webp" alt="Engine Image">
            </div>
          </div>
          <!-- <div class="col-lg-4  ">
            <div class="content-wraps">
            <div class="img-work mt-5">
            <img src="assets/images/about/i-1.png" alt="Engine Image" width="210px" height="210px">
            </div>
            </div>
          </div> -->
        </div>
      </div>

</section>
<!-- Page Banner Section - End
================================================== -->

<!-- Portfolio Section - Start
================================================== -->
<section class="portfolio_section section_space bg-light">
  <div class="container">
  
    <div class="filter_elements_wrapper row">

    <div class="col-lg-6 technology">
        <div class="portfolio_block portfolio_layout_2">
          <div class="portfolio_image">
            <a class="portfolio_image_wrap bg-light" href="blog-details-3">
              <img src="assets/images/portfolio/portfolio_item_image_12.webp" alt="Mobile App Design">
            </a>
          </div>
          <div class="portfolio_content">
          <a class="creative_btn mt-4" href="blog-details-3" >
                    <span class="btn_label bg-primary">Read More</span>
                  
                  </a>
            <h3 class="portfolio_title">
              <a href="blog-details-3">
              Mastering the Finances for Future Investment Success
              </a>
              
            </h3>
       
          
           
         
          </div>
       
        </div>
      </div>
      <div class="col-lg-6 technology">
        <div class="portfolio_block portfolio_layout_2">
          <div class="portfolio_image">
            <a class="portfolio_image_wrap bg-light" href="blog-details-1">
              <img src="assets/images/portfolio/portfolio_item_image_13.webp" alt="Mobile App Design">
            </a>
          </div>
          <div class="portfolio_content">
          <a class="creative_btn mt-4" href="blog-details-1" >
                    <span class="btn_label bg-primary">Read More</span>
                  
                  </a>
            <h3 class="portfolio_title">
              <a href="blog-details-1">
              International Medical Conference Webinars!
              </a>
              
            </h3>
       
          
           
         
          </div>
       
        </div>
      </div>
      <div class="col-lg-6 technology">
        <div class="portfolio_block portfolio_layout_2">
          <div class="portfolio_image">
            <a class="portfolio_image_wrap bg-light" href="blog-details-2">
              <img src="assets/images/portfolio/portfolio_item_image_14.webp" alt="Mobile App Design">
            </a>
          </div>
          <div class="portfolio_content">
          <a class="creative_btn mt-4" href="blog-details-2" >
                    <span class="btn_label bg-primary">Read More</span>
                  
                  </a>
            <h3 class="portfolio_title">
              <a href="blog-details-2">
              Embracing AI's Revolutionary Impact on Digital Marketing.
              </a>
              
            </h3>
       
          
           
         
          </div>
       
        </div>
      </div>
   
    
  
   
    </div>
  </div>
</section>
<!-- Portfolio Section - End
================================================== -->

<!-- Call To Action Section - Start
================================================== -->
<section class="calltoaction_section parallaxie" style="background-image: url('assets/images/backgrounds/bg_image_6.webp');">
  <div class="container text-center">
    <div class="heading_block text-white">
      <h2 class="heading_text">
        Ready to Work, Let's Chat
      </h2>
      <p class="heading_description mb-0">
        Our team of experts is ready to collaborate with you every step of the way, from initial consultation to implementation.
      </p>
    </div>
    <a class="btn btn-primary" href="contact">
      <span class="btn_label" data-text="Contact Us Today!">Contact Us Today!</span>
      <span class="btn_icon">
        <i class="fa-solid fa-arrow-up-right"></i>
      </span>
    </a>
  </div>
</section>
<!-- Call To Action Section - End
================================================== -->

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abish\Downloads\Bluggle_Groups_final\groups\resources\views\portfolio.blade.php ENDPATH**/ ?>