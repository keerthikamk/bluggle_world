
<?php $__env->startSection('title','Software and solution'); ?>
<?php $__env->startSection('content'); ?>
<main class="page_content">

<!-- Page Banner Section - Start
================================================== -->
<section class="software_company_hero_section xb-hidden ">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-12 a ">
            <div class="content-wraps text-center mt-3">
              <div class="content_wrap  ">
                <h1 class="text-white  ">
                Bluggle software  and <mark>Solution</mark> 
                   
                </h1>
                <h5 class="text-white mt-4 " ><i>"Empowering Innovation, Delivering Excellence!"</i> 
                </h5>
              </div>
            </div>
            <div class="shape_images_1">
              <img src="assets/images/hero/shape_image_1.webp" alt="Engine Image">
            </div>
            <div class="shape_images_2">
              <img src="assets/images/hero/shape_image_2.webp" alt="Engine Image">
            </div>
          </div>
          <!-- <div class="col-lg-4  ">
            <div class="content-wraps">
            <div class="img-work mt-5">
            <img src="assets/images/about/i-1.png" alt="Engine Image" width="210px" height="210px">
            </div>
            </div>
          </div> -->
        </div>
      </div>

    </section>
<!-- Page Banner Section - End
================================================== -->

<!-- Service Details Section - Start
================================================== -->



<section class="about_section pt-5 bg-white ">
    <div class="">
        <div class="col-lg-12 ">
            <div class="it_solution_hero_content bg-white">
                <h2 class="details_item_title" >
                 Software and Solution
                </h2>
                <p class="mb-0">
                Welcome to Bluggle Groups Software and Solutions, where innovation meets excellence. We are thrilled to have you join our community of forward-thinkers and problem-solvers dedicated to pushing the boundaries of technology and delivering top-tier solutions
                
                 <!-- <marquee behavior="" direction="left" scrollamount="10"loop="infinite" class="marks"><h5 class="mt-3"><mark>"Our squad is all about sparking connections with your peeps and making big waves with killer outcomes!"</mark></h5><h5 class="mt-3"><mark>"Our squad is all about sparking connections with your peeps and making big waves with killer outcomes!"</mark></h5></marquee> -->
                </p>
                <p class="mt-3">
              At Bluggle, we pride ourselves on our commitment to providing cutting-edge software and comprehensive solutions tailored to meet the unique needs of our clients.       One Solution at a Time. Our team of experts is passionate about transforming challenges into opportunities and ensuring that every project we undertake drives significant value and growth for your business. <mark class="typing-text-3" ></mark></p>
       
                    </div>
                </div>
          </div>
     
                </div>
              </div>
            </div>
         
</section>

<section class="service_section   pt-5 pb-5" >
          <div class="container br pt-5 pb-5 " style=" background-color: rgb(185,243,238)" >
            <div class="row align-items-center justify-content-lg-between">
              <div class="col-lg-6 ">
                  <div class="image_wrap ">
                    <div class="about_image_1">
                      <img src="assets/images/about/about_image_25.png" alt="Techco - About Image">
                      <!-- <img src="assets/images/about/about_image_11.webp" data-parallax='{"y" : 80, "smoothness": 6}' alt="Techco - About Image"> -->
                      <!-- <img src="assets/images/about/about_image_10.webp" data-parallax='{"y" : -80, "smoothness": 6}' alt="Techco - About Image"> -->
                    </div>
                  </div>
                  <div class="text-center mt-4">
                    <a class="btn btn-primary " href="contact">
                      <span class="btn_label" data-text="Enquiry">Enquiry</span>
                      <span class="btn_icon">
                        <i class="fa-solid fa-arrow-up-right"></i>
                      </span>
                    </a>
                  </div>
              </div>

              <div class="col-lg-6">
                <div class="pe-lg-5">
                  <div class="heading_block">
                  
                    <h2 class="heading_text mb-0">
                    HR-CLOUD
                    </h2>
                   <p class="mb-0 mt-2">
                   Introducing HR Cloud by Bluggle Groups: your all-in-one solution for seamless human resources management. Our cloud-based service simplifies employee management, payroll, time and attendance tracking, benefits administration, and performance reviews. Designed for businesses of all sizes, HR Cloud ensures data security, regulatory compliance, and offers the flexibility to grow with your organization. 
                   </p>
                  </div>
                  <ul class="service_facilities_group  unordered_list" >
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_check_2.svg" alt="Check SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">PAYROLL</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_leaf.svg" alt="Leaf SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">BENEFITS</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_box.svg" alt="Box SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">TIME & ATTENDANCE</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_receipt_add.svg" alt="Receipt Add SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">RECRUITING</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_monitor.svg" alt="Monitor SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">PULSE</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">PEO</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">SHEDULING</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">LEARNING MANAGEMENT</strong>
                        </span>
                      </a>
                    </li>
                    <!-- <li>
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">INTERNET</strong>
                        </span>
                      </a>
                    </li> -->
                   
                  </ul>
                </div>
            
              </div>
  
           
            </div>
          </div>
</section>
         <div class="container ">
        
         </div>   
      <section class="service_section   pt-5 pb-5" >
          <div class="container br pt-5 pb-5 " style=" background-color: rgb(228,252,227)" >
         
            <div class="row align-items-center justify-content-lg-between">
              <div class="col-lg-6 order-lg-last">
                <div class="image_wrap ps-lg-5 ">
                  <!-- <img src="assets/images/about/about_image_5.webp" alt="Techco - About Image"> -->
                  <div class="about_image_1">
                  <img src="assets/images/about/about_image_24.png" alt="Techco - About Image">
                  <!-- <img src="assets/images/about/about_image_11.webp" data-parallax='{"y" : 80, "smoothness": 6}' alt="Techco - About Image"> -->
                  <!-- <img src="assets/images/about/about_image_10.webp" data-parallax='{"y" : -80, "smoothness": 6}' alt="Techco - About Image"> -->
                </div>
              <div class="text-center mt-4">
              <a class="btn btn-primary " href="contact">
                <span class="btn_label" data-text="Enquiry">Enquiry</span>
                <span class="btn_icon">
                  <i class="fa-solid fa-arrow-up-right"></i>
                </span>
              </a>
              </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="pe-lg-5 ps-lg-5">
                  <div class="heading_block">
                  
                    <h2 class="heading_text mb-0">
                  IT CLOUD
                    </h2>
                   <p class="mb-0 mt-2">
                   At Bluggle Groups, we understand the evolving needs of modern businesses. Our IT Cloud Services are designed to provide scalable, secure, and reliable solutions tailored to optimize your operations and drive growth. With our expertise in cloud technologies, we empower your business to thrive in the digital age.
                   </p>
                  </div>
                  <ul class="service_facilities_group  lis" >
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_check_2.svg" alt="Check SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">APP MANAGEMENT</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_leaf.svg" alt="Leaf SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">DEVICE MANAGEMENT</strong>
                        </span>
                    
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_leaf.svg" alt="Leaf SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">INVENTORY MANAGEMENT</strong>
                        </span>
                    
                      </a>
                    </li>
              
                    <!-- <li>
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">INTERNET</strong>
                        </span>
                      </a>
                    </li> -->
                   
                  </ul>
                </div>
              </div>
            </div>
          </div>
</section>

<section class="service_section   pt-5 pb-5"  >
          <div class="container  br pt-5 pb-5" style="background-color: rgb(249,228,220) ">
            <div class="row align-items-center justify-content-lg-between">
              <div class="col-lg-6 ">
                <div class="image_wrap ">
                  <!-- <img src="assets/images/about/about_image_5.webp" alt="Techco - About Image"> -->
                  <div class="about_image_1">
                  <img src="assets/images/about/about_image_26.png" alt="Techco - About Image">
                  <!-- <img src="assets/images/about/about_image_11.webp" data-parallax='{"y" : 80, "smoothness": 6}' alt="Techco - About Image"> -->
                  <!-- <img src="assets/images/about/about_image_10.webp" data-parallax='{"y" : -80, "smoothness": 6}' alt="Techco - About Image"> -->
                </div>
                <div class="text-center mt-4">
              <a class="btn btn-primary " href="contact">
                <span class="btn_label" data-text="Enquiry">Enquiry</span>
                <span class="btn_icon">
                  <i class="fa-solid fa-arrow-up-right"></i>
                </span>
              </a>
              </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="pe-lg-5">
                  <div class="heading_block">
                  
                    <h2 class="heading_text mb-0">
                    DESIGN & DEVELOPMENT
                    </h2>
                   <p class="mb-0 mt-2">
                   At Bluggle, we see website design as a fun journey where we team up with you to blend style and substance. Together, let's whip up websites that are not just amazing but also super easy for your visitors to love!
                   </p>
                  </div>
               
 <ul class="service_facilities_group  lis" >
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_check_2.svg" alt="Check SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">CORPORATE CARDS</strong>
                        </span>
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_leaf.svg" alt="Leaf SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">EXPENSE MANAGEMENT</strong>
                        </span>
                    
                      </a>
                    </li>
                    <li style="background-color: transparent;">
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_leaf.svg" alt="Leaf SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">BILL PAY</strong>
                        </span>
                    
                      </a>
                    </li>
              
                    <!-- <li>
                      <a class="iconbox_block layout_icon_left" href="contact">
                        <span class="iconbox_icon">
                          <img src="assets/images/icons/icon_microscope.svg" alt="Microscope SVG Icon">
                        </span>
                        <span class="iconbox_content">
                          <strong class="iconbox_title mb-0">INTERNET</strong>
                        </span>
                      </a>
                    </li> -->
                   
                  </ul>

                </div>
              </div>
            </div>
          </div>
</section>

<section class="calltoaction_section parallaxie " style="background-image: url('assets/images/backgrounds/bg_image_6.webp');">
  <div class="container text-center">
    <div class="heading_block text-white">
      <h2 class="heading_text">
        Ready to Work, Let's Chat
      </h2>
      <p class="heading_description mb-0">
        Our team of experts is ready to collaborate with you every step of the way, from initial consultation to implementation.
      </p>
    </div>
    <a class="btn btn-primary" href="contact">
      <span class="btn_label" data-text="Contact Us Today!">Contact Us Today!</span>
      <span class="btn_icon">
        <i class="fa-solid fa-arrow-up-right"></i>
      </span>
    </a>
  </div>
</section>

      
       
<!-- <section class="service_details_section ha  ">
    <div class="">
        <div class="col-lg-12 ">
            <div class="it_solution_hero_content ha ">
            
           
            </div>
        </div>
    </div>
</section> -->



<!-- Service Details Section - End
================================================== -->

<!-- Call To Action Section - Start
================================================== -->

<!-- Call To Action Section - End
================================================== -->

</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abish\Downloads\Bluggle_Groups_final\groups\resources\views\bluggle-software-solution.blade.php ENDPATH**/ ?>