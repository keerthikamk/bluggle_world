

<?php $__env->startSection('title','Bluggle-Blogs'); ?>
<?php $__env->startSection('content'); ?>

<main class="page_content">

<!-- Page Banner Section - Start
================================================== -->
<section class="software_company_hero_section xb-hidden">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-12 a ">
            <div class="content-wraps text-center mt-3">
              <div class="content_wrap  ">
                <h1 class="text-white  ">
                Medical Conference <mark>Webinars</mark> 
                   
                </h1>
                <h6 class="text-white " >"Join us in advancing global healthcare through <mark class="ms-1"> knowledge and collaboration!"</mark>
                </h6>
              </div>
            </div>
            <div class="shape_images_1">
              <img src="assets/images/hero/shape_image_1.webp" alt="Engine Image">
            </div>
            <div class="shape_images_2">
              <img src="assets/images/hero/shape_image_2.webp" alt="Engine Image">
            </div>
          </div>
          <!-- <div class="col-lg-4  ">
            <div class="content-wraps">
            <div class="img-work mt-5">
            <img src="assets/images/about/i-1.png" alt="Engine Image" width="210px" height="210px">
            </div>
            </div>
          </div> -->
        </div>
      </div>

</section>

        <!-- Blog Details Section - Start
        ================================================== -->
        <section class="blog_details_section section_space bg-light">
          <div class="container">
            <div class="details_item_image">
              <img src="assets/images/blog/blog_post_image_23.webp" alt="Techco - Blog Image">
            </div>
            <!-- <div class="post_meta_wrap mb-4">
              <ul class="category_btns_group unordered_list">
                <li><a href="#!">Technology</a></li>
              </ul>
              <ul class="post_meta unordered_list">
                <li>
                  <a href="#!">
                    <img src="assets/images/icons/icon_calendar.svg" alt="Icon Calendar"> 11/12/2024
                  </a>
                </li>
              </ul>
            </div> -->
            <h2 class="details_item_title">
            Welcome to the International Medical Conference Webinars!
            </h2>
            <p>
            We are excited to present you to our International Medical Conference Webinars, an innovative platform that brings together medical experts, researchers, and students from all around the world. Our objective is to promote collaboration, exchange ground-breaking research, and offer valuable continuing education opportunities in the medical sector.
            </p>
         
            <hr class="mb-0">
            <div class="pt-4 pb-0">
              <div class="row">
                <div class="col-lg-8">
                
                  <h3 class="details_item_info_title mb-5">
                  Why attend virtual conferences?
                  </h3>
                  <div class="row mb-4">
                    <div class="col-md-6 col-sm-6">
                      <div class="details_item_image m-0">
                        <img src="assets/images/blog/blog_post_image_24.webp" alt="Techco - Blog Image">
                      </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                      <div class="details_item_image m-0">
                        <img src="assets/images/blog/blog_post_image_25.webp" alt="Techco - Blog Image">
                      </div>
                    </div>
                  </div>
                  <p>
                  In today's fast changing healthcare world, staying educated and engaged is more important than ever. By adopting the virtual format, we make our conferences available to a worldwide audience. You can participate in our webinars from anywhere and benefit from the experience of prominent doctors in a variety of medical fields.
                  </p>
                  <h3 class="details_item_info_title ">
                  What to Expect from Our Webinars?
                  </h3>
                  <p>
                  Our webinars cover a wide range of topics, from the most recent advances in medical research and breakthrough treatments to practical insights for clinical practice. Each session is meticulously planned to ensure that you obtain valuable knowledge and skills applicable to your job.
                  </p>

                  <h3 class="details_item_info_title">Discover the advantages of our international medical conference webinars</h3>
                  <p>
                  Are you interested about why our International Medical Conference Webinars are a must-attend event for medical professionals all over the world? Let me give you some fascinating details. We've asked renowned medical experts and researchers to offer their thoughts and experiences, giving you the opportunity to learn from and connect with the best in the field during interactive Q&As. Our webinars address the most critical issues in healthcare today, including global health challenges, technological advancements, novel treatment procedures, and patient care techniques. Understanding the value of continuing education, our webinars are designed to help you earn CME credits, ensuring you keep current with the newest advances and retain your professional certifications.
                  </p>
                  <p>Despite its virtual nature, our platform provides countless opportunities to connect with peers from all around the world. You can participate in debates, share experiences, and form valuable professional ties that will last a lifetime. Our sessions are not just passive listening; they include interactive features such as live polls, case studies, and group discussions to help you learn more effectively. You'll be able to ask questions and engage actively, making the sessions more interesting and instructive. One of the distinguishing features of our webinars is the global perspective they provide. You'll hear from specialists working in various healthcare systems and environments, receive insights into different practices and issues, and widen your professional horizons.</p>
                  <p>Recognizing that medical professionals are extremely busy, we've designed our webinars to be as easy and flexible as possible, with sessions planned at various times to accommodate different time zones and recordings available for those who are unable to attend live. Furthermore, our platform promotes collaborative research by connecting you with other participants and presenters, which leads to unique projects and studies. So why wait? Join us on this exciting adventure of learning, sharing, and growing together, and elevate your professional development to new heights!</p>
                
                  <h3 class="details_item_info_title">Join us on this exciting journey.</h3>
                  <p class="mb-2">
                  We believe that by collaborating in this virtual arena, we may transcend geographical obstacles and build a thriving community dedicated to expanding medical knowledge and improving patient outcomes.
                  </p>
                  <p>Whether you are an experienced medical professional or just starting out, our International Medical Conference Webinars have something for you. Join us on this amazing adventure of learning, sharing, and developing together.</p>
                  <p>Thank you for being a member of our community. We are looking forward to seeing you at our upcoming webinars!</p>
                 
                  <hr class="mt-0 mb-5">
            

              


                  <div class="comment_area mb-0">
                    <h3 class="details_item_info_title mb-1">Leave a Comment</h3>
                    <p class="mb-5">
                      Your email address will not be published. Required fields are marked <sup class="text-primary">*</sup>
                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="input_title" for="input_name">Full Name <sup class="text-primary">*</sup></label>
                          <input id="input_name" class="form-control" type="text" name="name"  required>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="input_title" for="input_email">Your Email <sup class="text-primary">*</sup></label>
                          <input id="input_email" class="form-control" type="email" name="email" required>
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="form-group">
                          <label class="input_title" for="input_textarea">Comments / Questions <sup class="text-primary">*</sup></label>
                          <textarea id="input_textarea" class="form-control" name="message" placeholder="How can we help you?"></textarea>
                        </div>
                        <div class="form-check mb-5">
                          <input class="form-check-input" type="checkbox" id="flexCheckDefault">
                          <label class="form-check-label" for="flexCheckDefault">
                            Save my name, email, and website in this browser for the next time I comment.
                          </label>
                        </div>
                        <button type="submit" class="btn btn-primary">
                          <span class="btn_label" data-text="Submit Comment">Submit Comment</span>
                          <span class="btn_icon">
                            <i class="fa-solid fa-arrow-up-right"></i>
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4">
                  <aside class="sidebar ps-lg-5">
                 
                    <div class="post_list_block">
                      <h3 class="sidebar_widget_title">Related Posts</h3>
                      <ul class="unordered_list_block">
                        <li>
                          <h3 class="post_title">
                            <a href="blog-details-2">
                            Embracing AI's Revolutionary Impact on Digital Marketing
                            </a>
                          </h3>
                          <!-- <ul class="post_meta unordered_list">
                            <li>
                              <a href="#!">
                                <img src="assets/images/icons/icon_calendar.svg" alt="Icon Calendar"> 11/12/2024
                              </a>
                            </li>
                            <li>
                              <a href="#!"><i class="fa-regular fa-comment-lines"></i> 24</a>
                            </li>
                          </ul> -->
                        </li>
                        <li>
                          <h3 class="post_title">
                            <a href="blog-details-1">
                            International Medical Conference Webinars!
                            </a>
                          </h3>
                          <!-- <ul class="post_meta unordered_list">
                            <li>
                              <a href="#!">
                                <img src="assets/images/icons/icon_calendar.svg" alt="Icon Calendar"> 11/12/2024
                              </a>
                            </li>
                            <li>
                              <a href="#!"><i class="fa-regular fa-comment-lines"></i> 24</a>
                            </li>
                          </ul> -->
                        </li>
                        
                      </ul>
                    </div>
                    <div class="post_category_wrap">
                      <h3 class="sidebar_widget_title">Services</h3>
                      <ul class="post_category_list unordered_list_block">
                        <li>
                          <a href="digital-marketing">
                            <i class="fa-solid fa-arrow-up-right"></i>
                            <span> Digital Marketing</span>
                            
                          </a>
                        </li>
                        <li>
                          <a href="Enterprise-Growth-Advisors">
                            <i class="fa-solid fa-arrow-up-right"></i>
                            <span>Enterprise Growth Advisors</span>
                          
                          </a>
                        </li>
                    
                        <li>
                          <a href="conference">
                            <i class="fa-solid fa-arrow-up-right"></i>
                            <span>Conferences</span>
                          
                          </a>
                        </li>
                        <li>
                          <a href="software-solution">
                            <i class="fa-solid fa-arrow-up-right"></i>
                            <span>Software and Solution</span>
                        
                          </a>
                        </li>
                        
                      </ul>
                    </div>
                    
                  </aside>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Blog Details Section - End
        ================================================== -->

        <!-- Call To Action Section - Start
        ================================================== -->
        <section class="calltoaction_section parallaxie" style="background-image: url('assets/images/backgrounds/bg_image_6.webp');">
          <div class="container text-center">
            <div class="heading_block text-white">
              <h2 class="heading_text">
                Ready to Work, Let's Chat
              </h2>
              <p class="heading_description mb-0">
                Our team of experts is ready to collaborate with you every step of the way, from initial consultation to implementation.
              </p>
            </div>
            <a class="btn btn-primary" href="contact.html">
              <span class="btn_label" data-text="Contact Us Today!">Contact Us Today!</span>
              <span class="btn_icon">
                <i class="fa-solid fa-arrow-up-right"></i>
              </span>
            </a>
          </div>
        </section>
        <!-- Call To Action Section - End
        ================================================== -->

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abish\Downloads\Bluggle_Groups_final\groups\resources\views\blog-details-1.blade.php ENDPATH**/ ?>