<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;


class AdminController extends Controller
{
    public function index()
    {
       $details= User::all();
       
     return view('admin-pannel')->with('details',$details);
    }
    public function store(Request $request)
    {
      $request->validate([
        'email' => 'required|unique:users',
     
    ]);
        $details = new User;
        $details->name=$request->input('name');
        $details->lastname=$request->input('lastname');
        $details->email=$request->input('email');
        $details->mobile=$request->input('mobile');
        $details->designation=$request->input('designation');
        $details->slot=$request->input('slot');
        $details->referal=$request->input('referal');
        $details->password='null';

        $details->save();
     
        return view('pricing');
      
       
// $to = $details->email; 


// $subject = 'Contact form mail test';

// $name = $request->input('name');
// $email='abishmehan3510@gmail.com';



// $message = "Hello ".$name." <br>
// Thank you for registering with Bluggle Webinars.<br>
// Date and Time of the lecture:<br>
// Jun 8, 2024 04:00 PM India <br><br>

// You can join directly through
// <a href='https://us05web.zoom.us/j/8799976670?pwd=ZscNdoCEfPu5uV0CiMamCqSMUWGLWU.1&omn=88174723532'>Click here to enter</a><br><br>


// Note: You should not share this link with others; As it is a link for you only.
// Passcode: 5LP3RG<br>

// You can add it to your calendar Add to Google calendar Add to Yahoo calendar<br>

// You can cancel your registration at any time.<br>

// If you need assistance, you can contact us at digital.support@blugglegroups.com<br>

// Best Regards from the Bluggle Webinar Team. <br>"
// ;



// $headers = "MIME-Version: 1.0" . "\r\n";
// $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// $headers .= 'From: '. $email . "\r\n";



// if(mail($to, $subject, $message, $headers)){
//   return back()->with('message','you have received a email invite');
// }
// else{
//   return back()->with('error','Something went wrong');
// }

    
    }
}
