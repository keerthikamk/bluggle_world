<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;

// Route::get('/', function () {
//     return view('welcome');
// });
Route::view('/', 'home');
Route::view('about', 'about');
Route::view('service', 'service');
Route::view('service/enterprise-Growth-Advisors', 'bluggle-enterprise');
Route::view('service/digital-marketing', 'bluggle-digital-marketing');
Route::view('education', 'bluggle-education');
Route::view('service/conference/bluggle-conference', 'bluggle-conference');
Route::view('webinar', 'bluggle-webinar');
Route::view('service/software-solution', 'bluggle-software-solution');
Route::view('portfolio', 'portfolio');
Route::view('contact', 'contact');
Route::view('blog-details-1', 'blog-details-1');
Route::view('blog-details-2', 'blog-details-2');
Route::view('blog-details-3', 'blog-details-3');
Route::view('register', 'register');
Route::view('service/conference/network-security', 'bluggle-network');
Route::view('service/conference/forex-webinar', 'bluggle-forex');
Route::view('pricing', 'pricing');
Route::get('pannel', [AdminController::class, 'index']) ;
Route::post('register', [AdminController::class, 'store']) ;


// Route::view('pannel', 'admin-pannel');



